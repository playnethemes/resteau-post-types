<?php
/*
 Plugin Name: Resteau Custom Post Types
 Plugin URI: http://themeforest.net/user/playnethemes
 Description: You will need to install this to fully use the Resteau theme. This plugin includes the following post types: menu, gallery, team, testimonials, features, team and Homepage. 
 Author: Playne Themes
 Author URI: http://themeforest.net/user/playnethemes
 Version: 1.0
 */

/**
 * Homepage items
 */
function resteau_homepage_custom_init() {

    $resteau_homepageitem_labels = array(
        'name'                  => esc_html_x('Homepage items', 'post type general name', 'resteau'),
        'singular_name'         => esc_html_x('Homepage item', 'post type singular name', 'resteau'),
        'add_new'               => esc_html_x('Add new', 'homepage item', 'resteau'),
        'add_new_item'          => esc_html__('Add homepage item', 'resteau'),
        'edit_item'             => esc_html__('Edit homepage item', 'resteau'),
        'new_item'              => esc_html__('New homepage item', 'resteau'),
        'view_item'             => esc_html__('View homepage item', 'resteau'),
        'search_items'          => esc_html__('Search homepage items', 'resteau'),
        'not_found'             => esc_html__('No homepage items found', 'resteau'),
        'not_found_in_trash'    => esc_html__('No homepage items found in trash', 'resteau'),
        'menu_name'             => esc_html__('Homepage', 'resteau')
    );

    $resteau_homepageitem_args = array(
        'labels'                => $resteau_homepageitem_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'public'                => false,
        'show_in_nav_menus'     => true,
        'menu_icon'             => 'dashicons-admin-home',
        'menu_position'         => 3,
        'publicly_queryable'    => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'hierarchical'          => false,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'homepageitem', $resteau_homepageitem_args );

}
add_action( 'init', 'resteau_homepage_custom_init' );

/*-----------------------------------------------------------------------------------

1.  Press
2.  Menu
3.  Gallery
4.  Testimonials
5.  Features
6.  Team

------------------------------------------------------------------------------------*/

/**
 * Press
 */
function resteau_press_custom_init() {

    $resteau_press_labels = array(
        'name'                  => esc_html_x('Press', 'post type general name', 'resteau'),
        'singular_name'         => esc_html_x('Press', 'post type singular name', 'resteau'),
        'add_new'               => esc_html_x('Add new', 'Press item', 'resteau'),
        'add_new_item'          => esc_html__('Add new press item', 'resteau'),
        'edit_item'             => esc_html__('Edit press item', 'resteau'),
        'new_item'              => esc_html__('New press item', 'resteau'),
        'view_item'             => esc_html__('View press item', 'resteau'),
        'search_items'          => esc_html__('Search press item', 'resteau'),
        'not_found'             => esc_html__('No press items found', 'resteau'),
        'not_found_in_trash'    => esc_html__('No press items found in trash', 'resteau'),
        'menu_name'             => esc_html__('Press', 'resteau'),
    );

    $resteau_press_args = array(
        'labels'                => $resteau_press_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-format-aside',
        'menu_position'         => 1,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-press', $resteau_press_args );

}
add_action( 'init', 'resteau_press_custom_init' );

/**
 * menu
 */
function resteau_menu_custom_init() {

    $resteau_menuitem_labels = array(
        'name'                  => esc_html_x('Menu', 'post type general name', 'resteau'),
        'singular_name'         => esc_html_x('Menu item', 'post type singular name', 'resteau'),
        'add_new'               => esc_html_x('Add new', 'Menu item', 'resteau'),
        'add_new_item'          => esc_html__('Add menu item', 'resteau'),
        'edit_item'             => esc_html__('Edit menu item', 'resteau'),
        'new_item'              => esc_html__('New menu item', 'resteau'),
        'view_item'             => esc_html__('View menu item', 'resteau'),
        'search_items'          => esc_html__('Search menu item', 'resteau'),
        'not_found'             => esc_html__('No menu items found', 'resteau'),
        'not_found_in_trash'    => esc_html__('No menu items found in trash', 'resteau'),
        'menu_name'             => esc_html__('Menu', 'resteau'),
    );

    $resteau_menuitem_args = array(
        'labels'                => $resteau_menuitem_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-clipboard',
        'menu_position'         => 1,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-menu', $resteau_menuitem_args );

    // Initialize New Taxonomy Labels
    $resteau_menuitem_category_labels = array(
        'name'                  => esc_html_x( 'Categories', 'taxonomy general name', 'resteau' ),
        'singular_name'         => esc_html_x( 'Category', 'taxonomy singular name', 'resteau' ),
        'search_items'          => esc_html__( 'Search categories', 'resteau' ),
        'all_items'             => esc_html__( 'All categories', 'resteau' ),
        'parent_item'           => esc_html__( 'Parent Categories', 'resteau' ),
        'parent_item_colon'     => esc_html__( 'Parent Categories:', 'resteau' ),
        'edit_item'             => esc_html__( 'Edit Category,', 'resteau' ),
        'update_item'           => esc_html__( 'Update Category', 'resteau' ),
        'add_new_item'          => esc_html__( 'Add new category', 'resteau' ),
        'new_item_name'         => esc_html__( 'New category', 'resteau' ),
    );

    // Custom taxonomy for Project Tags
    register_taxonomy('menu-categories',array('our-menu'), array(
        'hierarchical'          => true,
        'labels'                => $resteau_menuitem_category_labels,
        'show_ui'               => true,
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'categories' ),
    ));

}
add_action( 'init', 'resteau_menu_custom_init' );

/**
 * Gallery
 */
function resteau_galerij_custom_init() {

    $resteau_galerij_labels = array(
        'name'                  => esc_html_x('Gallery', 'post type general name', 'resteau'),
        'singular_name'         => esc_html_x('Gallery item', 'post type singular name', 'resteau'),
        'add_new'               => esc_html_x('Add new', 'Afbeelding', 'resteau'),
        'add_new_item'          => esc_html__('Add gallery item', 'resteau'),
        'edit_item'             => esc_html__('Edit gallery item', 'resteau'),
        'new_item'              => esc_html__('New gallery item', 'resteau'),
        'view_item'             => esc_html__('View gallery item', 'resteau'),
        'search_items'          => esc_html__('Search gallery item', 'resteau'),
        'not_found'             => esc_html__('No gallery items found', 'resteau'),
        'not_found_in_trash'    => esc_html__('No gallery items found in trash', 'resteau'),
        'menu_name'             => esc_html__('Gallery', 'resteau'),
    );

    $resteau_galerij_args = array(
        'labels'                => $resteau_galerij_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-images-alt',
        'menu_position'         => 1,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','thumbnail')
    );

    register_post_type( 'our-gallery', $resteau_galerij_args );

}
add_action( 'init', 'resteau_galerij_custom_init' );

/**
 * Testimonials
 */
function resteau_referenties_custom_init() {

    $resteau_referentie_labels = array(
        'name'                  => esc_html_x('Testimonials', 'post type general name', 'resteau'),
        'singular_name'         => esc_html_x('Testimonial', 'post type singular name', 'resteau'),
        'add_new'               => esc_html_x('Add new', 'Referentie', 'resteau'),
        'add_new_item'          => esc_html__('Add testimonial', 'resteau'),
        'edit_item'             => esc_html__('Edit testimonial', 'resteau'),
        'new_item'              => esc_html__('New testimonial', 'resteau'),
        'view_item'             => esc_html__('View testimonial', 'resteau'),
        'search_items'          => esc_html__('Search testimonial', 'resteau'),
        'not_found'             => esc_html__('No testimonials found', 'resteau'),
        'not_found_in_trash'    => esc_html__('No testimonials found in trash', 'resteau'),
        'menu_name'             => esc_html__('Testimonials', 'resteau'),
    );

    $resteau_referentie_args = array(
        'labels'                => $resteau_referentie_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-format-quote',
        'menu_position'         => 1,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-testimonials', $resteau_referentie_args );

}
add_action( 'init', 'resteau_referenties_custom_init' );

/**
 * Features
 */
function resteau_features_custom_init() {

    $resteau_feature_labels = array(
        'name'                  => esc_html_x('Features', 'post type general name', 'resteau'),
        'singular_name'         => esc_html_x('Feature', 'post type singular name', 'resteau'),
        'add_new'               => esc_html_x('Add new', 'Feature', 'resteau'),
        'add_new_item'          => esc_html__('Add feature', 'resteau'),
        'edit_item'             => esc_html__('Edit feature', 'resteau'),
        'new_item'              => esc_html__('New feature', 'resteau'),
        'view_item'             => esc_html__('View feature', 'resteau'),
        'search_items'          => esc_html__('Search features', 'resteau'),
        'not_found'             => esc_html__('No features found', 'resteau'),
        'not_found_in_trash'    => esc_html__('No features found in trash', 'resteau'),
        'menu_name'             => esc_html__('Features', 'resteau'),
    );

    $resteau_feature_args = array(
        'labels'                => $resteau_feature_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-editor-ul',
        'menu_position'         => 1,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail')
    );

    register_post_type( 'our-features', $resteau_feature_args );

}
add_action( 'init', 'resteau_features_custom_init' );

/**
 * Team
 */
function resteau_team_custom_init() {

    $resteau_team_labels = array(
        'name'                  => esc_html_x('Team', 'post type general name', 'resteau'),
        'singular_name'         => esc_html_x('Member', 'post type singular name', 'resteau'),
        'add_new'               => esc_html_x('Add new', 'member', 'resteau'),
        'add_new_item'          => esc_html__('Add member', 'resteau'),
        'edit_item'             => esc_html__('Edit member', 'resteau'),
        'new_item'              => esc_html__('New member', 'resteau'),
        'view_item'             => esc_html__('View member', 'resteau'),
        'search_items'          => esc_html__('Search members', 'resteau'),
        'not_found'             => esc_html__('No members found', 'resteau'),
        'not_found_in_trash'    => esc_html__('No members found in trash', 'resteau'),
        'menu_name'             => esc_html__('Team', 'resteau'),
    );

    $resteau_team_args = array(
        'labels'                => $resteau_team_labels,
        'exclude_from_search'   => true,
        'show_in_nav_menus'     => false,
        'menu_icon'             => 'dashicons-groups',
        'menu_position'         => 1,
        'publicly_queryable'    => false,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'query_var'             => true,
        'rewrite'               => true,
        'capability_type'       => 'post',
        'has_archive'           => true,
        'hierarchical'          => false,
        'menu_position'         => null,
        'supports'              => array('title','editor','thumbnail','excerpt')
    );

    register_post_type( 'our-team', $resteau_team_args );

}
add_action( 'init', 'resteau_team_custom_init' );